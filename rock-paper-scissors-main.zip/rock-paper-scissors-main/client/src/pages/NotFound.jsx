export default function NotFound() {
  return <div>Not Found Page</div>;
}
