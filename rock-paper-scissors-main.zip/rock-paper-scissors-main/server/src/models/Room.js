class Room {
  constructor() {
    this.players = {};
    this.p1Choice = null;

    this.p2Choice = null;
    this.usernames = {};
  }
}

module.exports = Room;
